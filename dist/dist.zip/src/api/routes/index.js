module.exports = async ctx => {
  ctx.body = 'API Entry point';
};
