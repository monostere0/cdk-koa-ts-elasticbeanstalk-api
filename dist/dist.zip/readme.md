# Tech gigs API

This application is deployed through AWS Elastic Beanstalk via Docker.
Make sure you've got eb CLI installed locally, after that you can do

```
eb deploy
```

Which will deploy the API to http://tech-gigs-api.uyitkjajms.eu-central-1.elasticbeanstalk.com/